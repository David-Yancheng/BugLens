static void _techpack_stub(void)
{
}
